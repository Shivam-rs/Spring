package com.masteringspringfw.masteringspringfw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MasteringSpringFwApplicationTests {

	@Test
	void contextLoads() {
	}

}

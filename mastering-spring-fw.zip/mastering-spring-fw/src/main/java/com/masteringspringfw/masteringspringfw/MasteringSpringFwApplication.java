package com.masteringspringfw.masteringspringfw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasteringSpringFwApplication {

	public static void main(String[] args) {
		SpringApplication.run(MasteringSpringFwApplication.class, args);
	}

}

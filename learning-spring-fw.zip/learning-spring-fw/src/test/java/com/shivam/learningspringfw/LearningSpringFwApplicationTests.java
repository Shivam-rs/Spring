package com.shivam.learningspringfw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningSpringFwApplicationTests {

	@Test
	void contextLoads() {
	}

}

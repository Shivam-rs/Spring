package com.shivam.learningspringfw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningSpringFwApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningSpringFwApplication.class, args);
	}

}
